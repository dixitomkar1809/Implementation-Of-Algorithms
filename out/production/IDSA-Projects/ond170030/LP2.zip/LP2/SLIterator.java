package ond170030.LP2;

public interface SLIterator<T> {
    boolean hasNext();
    T next();
    void remove();
}